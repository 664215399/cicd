<script setup lang="ts">
import ImageUpload from './components/ImageUpload.vue'
</script>

<template>
  <div>
    <ImageUpload />
  </div>
</template>

<style scoped></style>